package com.example.stock;

public interface StockSerivceInterface {
    Stock addStock(Stock stock);
    void deleteById(Integer id);
    void update(Integer id,Stock stock);
    Integer getNumberInStock(Integer productNumber);

}
