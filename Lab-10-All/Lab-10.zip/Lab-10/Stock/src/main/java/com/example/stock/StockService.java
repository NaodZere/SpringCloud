package com.example.stock;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class StockService implements StockSerivceInterface {

    @Autowired
    StockRepo stockRepo;

    @Override
    public Stock addStock(Stock stock) {
        return stockRepo.save(stock);
    }

    @Override
    public void deleteById(Integer id) {
        stockRepo.deleteById(id);
    }

    @Override
    public void update(Integer id, Stock stock) {
          var stock1= stockRepo.findById(id).get();
          stock1.setQuantity(stock.getQuantity());
          stock1.setProductNumber(stock.getProductNumber());
          stockRepo.save(stock);
    }

    @Override
    public Integer getNumberInStock(Integer productNumber) {
        return 100;
    }
}
