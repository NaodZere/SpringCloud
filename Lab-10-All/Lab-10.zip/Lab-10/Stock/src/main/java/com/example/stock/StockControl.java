package com.example.stock;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
public class StockControl {
    @Autowired
    StockSerivceInterface stockSerivceInterface;
    @PostMapping("/stock/add")
    public Stock addStock(@RequestBody Stock stock) {
        return stockSerivceInterface.addStock(stock);
    }

    @DeleteMapping("/stock/delete/{id}")
    public void deleteById(@PathVariable Integer id) {
        stockSerivceInterface.deleteById(id);
    }

    @PutMapping("/stock/update/{id}")
    public void update(@PathVariable Integer id, @RequestBody Stock stock) {
       stockSerivceInterface.update(id,stock);
    }
    @GetMapping("/stock/numberInStock")
    public Integer getNumberInStock(Integer productNumber){
       return  stockSerivceInterface.getNumberInStock(productNumber);
    }
}
