package productcommandservice.lab10.ProductService.IMP;

import productcommandservice.lab10.Domain.Product;

public interface ProductServiceIMP {
    Product addProduct(Product p);

    void deleteById(Integer id);

    void update(Integer productNumber, Product product);


    Integer getNumberOfProducts(Integer productNumber);
}