package productcommandservice.lab10.ProductService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import productcommandservice.lab10.Domain.Product;
import productcommandservice.lab10.ProdcutRepository.ProductRepo;
import productcommandservice.lab10.ProductService.IMP.ProductServiceIMP;

import java.util.List;

@Service
public class ProductService implements ProductServiceIMP {
    @Autowired
    ProductRepo productRepo;
    @Autowired
    CQRSfeign cqrSfeign;

    @Autowired
    StockServiceFeignClient stockServiceFeignClient;


    @Override
    public Product addProduct(Product p) {
        var a=productRepo.save(p);
        cqrSfeign.save(p);
        return a;
    }

    @Override
    public void deleteById(Integer id) {
        productRepo.deleteById(id);
    }

    @Override
    public void update(Integer id, Product product) {
        var prod= productRepo.findById(id).get();
        prod.setName(product.getName());
//        prod.setProductNumber(product.getProductNumber());
        prod.setNumberInStock(product.getNumberInStock());
        productRepo.save(prod);
        cqrSfeign.save(prod);
    }

    @Override
    public Integer getNumberOfProducts(Integer productNumber) {
        return stockServiceFeignClient.getNumberInStock(productNumber);
    }
    @FeignClient(name="product" , url="http://localhost:8081")
    interface StockServiceFeignClient{
        @GetMapping("/stock/numberInStock")
        public Integer getNumberInStock(Integer productNumber);
    }

    @FeignClient(name="cqrs" , url ="http://localhost:8083")
    interface CQRSfeign{
        @GetMapping("/cqrs/allProducts")
        public List<Product> findall();
        @GetMapping("/cqrs/product/{id}")
        public Product findProduct(@PathVariable Integer id);
        @PostMapping("/cqrs/save")
        public Product save(@RequestBody Product product);
    }
//}
}
