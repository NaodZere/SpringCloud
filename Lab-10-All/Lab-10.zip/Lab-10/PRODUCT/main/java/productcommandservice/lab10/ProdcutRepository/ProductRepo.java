package productcommandservice.lab10.ProdcutRepository;

import org.springframework.boot.autoconfigure.data.jpa.JpaRepositoriesAutoConfiguration;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import productcommandservice.lab10.Domain.Product;

public interface ProductRepo extends JpaRepository<Product, Integer> {
}
