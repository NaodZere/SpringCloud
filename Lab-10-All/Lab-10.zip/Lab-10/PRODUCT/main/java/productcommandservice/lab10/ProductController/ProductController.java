package productcommandservice.lab10.ProductController;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import productcommandservice.lab10.Domain.Product;
import productcommandservice.lab10.ProductService.IMP.ProductServiceIMP;

@Controller
public class ProductController {

    @Autowired
    ProductServiceIMP productServiceIMP;

    @PostMapping("/product/add")
    public Product addProduct(@RequestBody Product p) {
        return productServiceIMP.addProduct(p);
    }

    @DeleteMapping("/product/{id}")
    public void deleteById(@PathVariable Integer id) {
        productServiceIMP.deleteById(id);
    }

    @GetMapping("/product/numberInStock")
    public Integer getNumberOfProducts(Integer productNumber){
        return  productServiceIMP.getNumberOfProducts(productNumber);
    }
    @PutMapping("/product/update/{id}")
    public void update(@PathVariable Integer id,@RequestBody Product product) {
        productServiceIMP.update(id,product);
    }

}
