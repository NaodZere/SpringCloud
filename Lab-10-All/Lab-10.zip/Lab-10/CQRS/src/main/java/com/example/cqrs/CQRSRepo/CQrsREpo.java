package com.example.cqrs.CQRSRepo;

import com.example.cqrs.Domain.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CQrsREpo extends JpaRepository<Product,Integer> {
}
