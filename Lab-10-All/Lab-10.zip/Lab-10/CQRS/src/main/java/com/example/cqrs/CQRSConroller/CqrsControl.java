package com.example.cqrs.CQRSConroller;

import com.example.cqrs.CQRSService.CQRSserviceINterface;
import com.example.cqrs.Domain.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class CqrsControl {
    @Autowired
    CQRSserviceINterface cqrSserviceINterface;
    @GetMapping("/cqrs/allProducts")
    public List<Product> findall(){
        return cqrSserviceINterface.getAll();
    }
    @GetMapping("/cqrs/product/{id}")
    public Product findProduct(@PathVariable Integer id){
        return cqrSserviceINterface.getProduct(id);
    }
    @PostMapping("/cqrs/save")
    public Product save(@RequestBody Product product){
        return cqrSserviceINterface.save(product);
    }

}
