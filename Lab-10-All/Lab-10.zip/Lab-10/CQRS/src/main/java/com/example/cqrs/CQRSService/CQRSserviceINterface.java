package com.example.cqrs.CQRSService;

import com.example.cqrs.Domain.Product;

import java.util.List;

public interface CQRSserviceINterface {
    List<Product> getAll();
    Product  getProduct(Integer id);

    Product save(Product product);
}
