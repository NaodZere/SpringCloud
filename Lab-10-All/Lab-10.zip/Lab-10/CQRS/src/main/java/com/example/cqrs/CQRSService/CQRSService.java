package com.example.cqrs.CQRSService;

import com.example.cqrs.CQRSRepo.CQrsREpo;
import com.example.cqrs.Domain.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class CQRSService implements CQRSserviceINterface {
    @Autowired
    CQrsREpo cQrsREpo;


    @Override
    public List<Product> getAll() {
        return cQrsREpo.findAll();
    }

    @Override
    public Product getProduct(Integer id) {
        return cQrsREpo.findById(id).get();
    }

    @Override
    public Product save(Product product) {
        return cQrsREpo.save(product);
    }
}
